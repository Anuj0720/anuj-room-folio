import { useCallback, useEffect, useRef } from "react";
import { useGLTF } from "@react-three/drei";
import { useThree } from "@react-three/fiber";
import * as THREE from "three";
import { DEFAULT_CAMERA, moveCamera } from "../../helper/cameraMover";
import { TV_ZOOM } from "../../helper/cameraPositions";
import {
  getSpidermanVideoTexture,
  getSpidermanVideoElement,
} from "../../helper/video";
import { registerCursorTarget, setHover, clearHover } from "../../helper/cursorManager";

export function Tv({
  onZoomIn,
  onZoomComplete,
  resetCameraRef,
  onResetComplete,
  tvScreenAnimCompleteRef,
}) {
  useGLTF("/models/room.glb");
  const { camera, controls, gl, scene } = useThree();
  const isAnimating = useRef(false);
  const isZoomedIn = useRef(false);
  const tvScreenRef = useRef(null);
  const tvVideoMaterialRef = useRef(null);
  const tvVideoTextureRef = useRef(null);
  const tvVideoElement = useRef(null);
  const hoveredMesh = useRef(null);


  useEffect(() => {
    if (!scene) return;

    const videoTexture = getSpidermanVideoTexture();
    const videoElement = getSpidermanVideoElement();
    tvVideoElement.current = videoElement;
    if (!videoTexture) return;

    videoTexture.flipY = false;
    videoTexture.needsUpdate = true;

    scene.traverse((child) => {
      if (!child.isMesh) return;
      const name = (child.name || "").toLowerCase();
      if (name.includes("tv_screen")) {
        const material = new THREE.MeshBasicMaterial({
          map: videoTexture,
          transparent: true,
          opacity: 0,
          toneMapped: false,
        });
        child.material = material;
        child.material.needsUpdate = true;
        tvScreenRef.current = child;
        tvVideoMaterialRef.current = material;
        tvVideoTextureRef.current = videoTexture;
      }
    });
  }, [scene]);

  const resetCamera = useCallback(() => {
    if (isAnimating.current) return;
    isAnimating.current = true;

    moveCamera({
      camera,
      controls,
      position: DEFAULT_CAMERA.position,
      target: DEFAULT_CAMERA.target,
      onComplete: () => {
        isAnimating.current = false;
        isZoomedIn.current = false;
        if (tvVideoElement.current) {
          tvVideoElement.current.muted = true;
        }
        onResetComplete?.();
      },
    });
  }, [camera, controls, onResetComplete]);

  useEffect(() => {
    if (!resetCameraRef) return;
    resetCameraRef.current = resetCamera;
  }, [resetCameraRef, resetCamera]);

  useEffect(() => {
    const handleTvScreenAnimComplete = () => {
      const material = tvVideoMaterialRef.current;
      const videoTexture = tvVideoTextureRef.current;
      if (!material || !videoTexture) return;
      material.map = videoTexture;
      material.opacity = 1;
      material.needsUpdate = true;
    };

    if (tvScreenAnimCompleteRef) {
      tvScreenAnimCompleteRef.current = handleTvScreenAnimComplete;
    }

    return () => {
      if (tvScreenAnimCompleteRef) {
        tvScreenAnimCompleteRef.current = null;
      }
    };
  }, [tvScreenAnimCompleteRef]);

  useEffect(() => {
    if (!gl || !camera || !controls) return;
    registerCursorTarget(gl.domElement);
    const raycaster = new THREE.Raycaster();
    const pointer = new THREE.Vector2();

    const handlePointerMove = (event) => {
      const rect = gl.domElement.getBoundingClientRect();
      pointer.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
      pointer.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;
      raycaster.setFromCamera(pointer, camera);

      const intersects = tvScreenRef.current
        ? raycaster.intersectObject(tvScreenRef.current, false)
        : [];

      if (intersects.length > 0) {
        setHover("tv", true);
        hoveredMesh.current = intersects[0].object;
      } else {
        setHover("tv", false);
        hoveredMesh.current = null;
      }
    };

    const handleClick = () => {
      if (!hoveredMesh.current) return;
      if (isZoomedIn.current) return;
      if (isAnimating.current) return;

      isZoomedIn.current = true;
      isAnimating.current = true;
      onZoomIn?.();
      if (tvVideoElement.current) {
        tvVideoElement.current.play().catch(() => {});
      }

      moveCamera({
        camera,
        controls,
        position: TV_ZOOM.position,
        target: TV_ZOOM.target,
        onComplete: () => {
          isAnimating.current = false;
          onZoomComplete?.();
          if (tvVideoElement.current) {
            tvVideoElement.current.muted = false;
            tvVideoElement.current.play().catch(() => {});
          }
        },
      });
    };

    gl.domElement.addEventListener("pointermove", handlePointerMove);
    gl.domElement.addEventListener("click", handleClick);

    return () => {
      clearHover("tv");
      gl.domElement.removeEventListener("pointermove", handlePointerMove);
      gl.domElement.removeEventListener("click", handleClick);
    };
  }, [gl, camera, controls, onZoomIn, onZoomComplete]);

  return null;
}

useGLTF.preload("/models/room.glb");
