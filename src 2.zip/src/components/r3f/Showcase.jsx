import { useGLTF } from "@react-three/drei";
import { useEffect, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import { useControls, folder } from "leva";
import * as THREE from "three";
import {
  createDissolveEffect,
  getAverageTextureColor,
} from "../../shader/dissolveShader";

// Substring-matched against each mesh's lowercased name, same
// convention Socials.jsx uses for its own mesh lookup.
const DISSOLVE_MESH_NAMES = ["pikachu", "snorlax", "vr", "pokeball"];

const FALLBACK_EDGE_COLOR = new THREE.Color("#ff6600");
const FALLBACK_PARTICLE_COLOR = new THREE.Color("#ffaa33");

export function Showcase() {
  const { scene } = useGLTF("/models/room.glb");

  // Each entry: { effect, index, textureEdgeColor, textureParticleColor }
  const effectsRef = useRef([]);

  const {
    cycleDuration,
    edgeWidth,
    frequency,
    amplitude,
    particleCount,
    particleSize,
    particleSpeed,
    phaseStep,
    useTextureColor,
    edgeColor,
    particleColor,
  } = useControls("Dissolve Effect", {
    timing: folder({
      cycleDuration: { value: 16, min: 4, max: 40, step: 1, label: "cycle (s)" },
      phaseStep: { value: 1.4, min: 0, max: 6, step: 0.1, label: "stagger (s)" },
    }),
    shape: folder({
      edgeWidth: { value: 0.08, min: 0.01, max: 0.4, step: 0.01 },
      frequency: { value: 2.0, min: 0.2, max: 6, step: 0.1 },
      amplitude: { value: 1.0, min: 0.2, max: 2, step: 0.05 },
    }),
    particles: folder({
      particleCount: { value: 600, min: 50, max: 2000, step: 50 },
      particleSize: { value: 60, min: 5, max: 200, step: 5 },
      particleSpeed: { value: 0.6, min: 0, max: 3, step: 0.05 },
    }),
    color: folder({
      useTextureColor: { value: true, label: "match mesh texture" },
      edgeColor: { value: "#ff6600", render: (get) => !get("Dissolve Effect.color.useTextureColor") },
      particleColor: { value: "#ffaa33", render: (get) => !get("Dissolve Effect.color.useTextureColor") },
    }),
  });

  // ── Find target meshes, patch materials, build particle systems ──
  useEffect(() => {
    if (!scene) return;

    const effects = [];
    let matchIndex = 0;

    scene.traverse((child) => {
      if (!child.isMesh) return;

      const name = child.name.toLowerCase();
      const matched = DISSOLVE_MESH_NAMES.some((target) => name.includes(target));
      if (!matched) return;

      // Clone the material before patching it — onBeforeCompile mutates
      // the material in place, and GLTF meshes sometimes share a single
      // material instance, which would otherwise leak the dissolve
      // patch onto unrelated meshes.
      child.material = child.material.clone();

      // Pull a color out of whatever texture this mesh already has,
      // instead of picking an arbitrary one — falls back to the
      // material's own tint, then to a plain default if neither
      // is available (e.g. an untextured/CORS-blocked texture).
      const derivedColor =
        getAverageTextureColor(child.material.map) ??
        (child.material.color ? child.material.color.clone() : null);
      const textureEdgeColor = derivedColor ? derivedColor.clone() : FALLBACK_EDGE_COLOR.clone();
      const textureParticleColor = derivedColor
        ? derivedColor.clone().offsetHSL(0, 0, 0.15)
        : FALLBACK_PARTICLE_COLOR.clone();

      const effect = createDissolveEffect(child, {
        cycleDuration,
        phase: matchIndex * phaseStep,
        edgeWidth,
        frequency,
        amplitude,
        particleCount,
        particleSize,
        particleSpeed,
        edgeColor: useTextureColor ? textureEdgeColor : new THREE.Color(edgeColor),
        particleColor: useTextureColor ? textureParticleColor : new THREE.Color(particleColor),
      });

      child.add(effect.points);
      effects.push({ effect, index: matchIndex, textureEdgeColor, textureParticleColor });
      matchIndex += 1;
    });

    effectsRef.current = effects;

    return () => {
      effects.forEach(({ effect }) => effect.dispose());
      effectsRef.current = [];
    };
    // particleCount changes the particle buffer's size, so it has to
    // rebuild; every other slider is pushed to the already-running
    // effects below via setParams instead, so dragging those doesn't
    // rebuild materials/particles on every frame of a drag.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [scene, particleCount]);

  // ── Push live Leva values into the already-running effects ───────
  useEffect(() => {
    effectsRef.current.forEach(({ effect, index, textureEdgeColor, textureParticleColor }) => {
      effect.setParams({
        cycleDuration,
        phase: index * phaseStep,
        edgeWidth,
        frequency,
        amplitude,
        particleSize,
        particleSpeed,
        edgeColor: useTextureColor ? textureEdgeColor : new THREE.Color(edgeColor),
        particleColor: useTextureColor ? textureParticleColor : new THREE.Color(particleColor),
      });
    });
  }, [
    cycleDuration,
    phaseStep,
    edgeWidth,
    frequency,
    amplitude,
    particleSize,
    particleSpeed,
    useTextureColor,
    edgeColor,
    particleColor,
  ]);

  useFrame((state) => {
    effectsRef.current.forEach(({ effect }) => effect.update(state.clock.elapsedTime));
  });

  return null;
}

useGLTF.preload("/models/room.glb");
