import * as THREE from "three";

// ─────────────────────────────────────────────────────────────────
// Loading Reveal — spiral wipe
//
// A polar-coordinate spiral mask: bands of alternating opaque/clear
// wind outward from the center, swept forward by uProgression. Two
// growing circle masks are layered on top so the reveal is staged —
// it starts right at the center and expands outward (25%-80% of the
// transition), then a second, later circle (50%-100%) clears the
// remaining middle so the transition closes cleanly instead of
// leaving a spiral pattern frozen in place. The base spiral formula
// is the well-known public ShaderToy technique (shadertoy.com/view/MslyWB).
// ─────────────────────────────────────────────────────────────────

const vertexShader = /* glsl */ `
  varying vec2 vUv;

  void main() {
    vUv = uv;
    gl_Position = vec4(position.xy, 0.0, 1.0);
  }
`;

const fragmentShader = /* glsl */ `
  uniform vec3 uColor;
  uniform float uProgression; // 0 = fully covered, 1 = fully revealed
  uniform vec2 uResolution;
  uniform float uArms;        // spiral arm density
  uniform float uTightness;   // how tightly the spiral winds toward the edge

  varying vec2 vUv;

  const float PI = 3.141592654;

  void main() {
    vec2 uvs = vUv - 0.5;
    uvs.x *= uResolution.x / uResolution.y; // keep the spiral circular, not stretched

    float r = length(uvs * 0.92);
    float theta = atan(uvs.y, uvs.x);

    // Base spiral pattern: alternating bands winding outward from the
    // center, swept forward by uProgression so they travel over time.
    float spiral = fract(uArms * theta / PI + uTightness * pow(r, 0.4) - 4.5 * uProgression);

    // Stage 1 — the spiral bands fade in starting at 25% through the
    // transition (a rising threshold turns solid bands into "revealed"
    // gaps one by one instead of all popping clear at once).
    float spiralThreshold = smoothstep(0.25, 1.0, uProgression);
    float alphaSpiral = step(spiralThreshold, spiral);

    // Stage 2 — a plain growing circle (25% -> 80%) so the reveal
    // starts at dead center and expands outward, rather than the
    // spiral pattern showing gaps out at the edges immediately.
    float circleThreshold = smoothstep(0.25, 0.8, uProgression);
    float alphaCircle = step(circleThreshold, r);
    float alpha = max(alphaSpiral, alphaCircle);

    // Stage 3 — a second, later circle (50% -> 100%) clears whatever
    // spiral pattern is still left in the middle, so it closes out
    // clean instead of freezing a spiral shape at full reveal.
    float closeThreshold = smoothstep(0.5, 1.0, uProgression);
    float alphaClose = step(closeThreshold, r);
    alpha = min(alpha, alphaClose);

    if (alpha < 0.02) discard; // fully revealed here — let the scene show through
    gl_FragColor = vec4(uColor, alpha);
  }
`;

export function createSpiralRevealMaterial(options = {}) {
  const {
    color = "#0e0e0e",
    arms = 2.5,
    tightness = 7.0,
  } = options;

  // Accept either a plain hex string (e.g. from a Leva color control)
  // or an existing THREE.Color — normalize to a real THREE.Color so
  // the uniform can always be safely mutated later via .set(...).
  const colorValue = color instanceof THREE.Color ? color : new THREE.Color(color);

  return new THREE.ShaderMaterial({
    uniforms: {
      uColor: { value: colorValue },
      uProgression: { value: 0 },
      uResolution: { value: new THREE.Vector2(1, 1) },
      uArms: { value: arms },
      uTightness: { value: tightness },
    },
    vertexShader,
    fragmentShader,
    transparent: true,
    depthTest: false,
    depthWrite: false,
  });
}

function easeInOutCubic(t) {
  return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
}

// Sets up its own tiny transparent-background renderer + full-screen
// quad, and animates uProgression from 0 to 1 over `duration` ms so
// the spiral opens up, revealing whatever's rendering underneath.
// Returns a handle with the DOM element to mount and a dispose().
export function createLoadingReveal({ duration = 3600, onComplete, ...materialOptions } = {}) {
  const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.setClearColor(0x000000, 0);

  const scene = new THREE.Scene();
  const camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0.1, 10);
  camera.position.z = 1;

  const material = createSpiralRevealMaterial(materialOptions);
  material.uniforms.uResolution.value.set(window.innerWidth, window.innerHeight);

  const quad = new THREE.Mesh(new THREE.PlaneGeometry(2, 2), material);
  scene.add(quad);

  // Mutable so duration can be retuned live (e.g. from Leva) while the
  // reveal is already running, instead of being frozen at creation.
  const state = { duration };

  let rafId = null;
  let startTime = null;
  let finished = false;

  const handleResize = () => {
    renderer.setSize(window.innerWidth, window.innerHeight);
    material.uniforms.uResolution.value.set(window.innerWidth, window.innerHeight);
  };
  window.addEventListener("resize", handleResize);

  const tick = (now) => {
    if (startTime === null) startTime = now;
    const raw = Math.min((now - startTime) / state.duration, 1);
    const eased = easeInOutCubic(raw);

    material.uniforms.uProgression.value = eased;
    renderer.render(scene, camera);

    if (raw >= 1) {
      finished = true;
      onComplete?.();
      return;
    }
    rafId = requestAnimationFrame(tick);
  };
  rafId = requestAnimationFrame(tick);

  function setDuration(newDuration) {
    state.duration = newDuration;
  }

  function setColor(newColor) {
    material.uniforms.uColor.value.set(newColor);
  }

  function dispose() {
    if (rafId !== null) cancelAnimationFrame(rafId);
    window.removeEventListener("resize", handleResize);
    quad.geometry.dispose();
    material.dispose();
    renderer.dispose();
  }

  return {
    domElement: renderer.domElement,
    dispose,
    setDuration,
    setColor,
    get finished() { return finished; },
  };
}
