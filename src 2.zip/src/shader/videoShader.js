import * as THREE from "three";

// ─────────────────────────────────────────────────────────────────
// Object-Space Line Art
//
// Instead of hunting for edges in a rendered image, this works out
// the silhouette directly from the mesh's own triangles: for every
// edge shared by exactly two triangles, it checks whether the two
// triangles disagree about facing the camera. If one faces the
// camera and its neighbour faces away, that edge sits on the
// silhouette and gets inked. An edge with only one adjacent
// triangle (an open/boundary edge) has nothing to disagree with, so
// it's always inked.
//
// The surviving edges are chained end-to-end into continuous
// strokes with a measurable arc length, which is what lets this
// technique place gaps ("lifts") at specific points along a line
// instead of just punching random holes in it.
//
// Two things make the result read as hand-drawn rather than
// computed:
//   • boil — the whole thing is only recomputed a few times a
//     second and held perfectly still in between (like animation
//     shot "on twos"), instead of updating every frame.
//   • lifts — gaps placed along each stroke's arc length, re-rolled
//     on every boil tick, so the line looks like a pen lifting off
//     the page rather than a perfectly continuous computer line.
// ─────────────────────────────────────────────────────────────────

const vertexShader = /* glsl */ `
  attribute vec3 aStart;
  attribute vec3 aEnd;
  attribute float aSide;   // -1 or 1 — which side of the stroke this vertex is on
  attribute float aArc;    // distance travelled along the stroke so far
  attribute float aJitter; // per-stroke random seed for the sketchy wobble

  uniform float uThickness;  // line thickness, in world units
  uniform vec2 uResolution;  // viewport size, so thickness reads consistently
  uniform float uBoilTime;   // current boil tick — only changes a few times/sec

  varying float vArc;
  varying float vJitter;
  varying float vAcross; // -1..1 across the stroke width, for rounded caps

  // Cheap hash noise. Keyed by the boil tick (not real time) so the
  // wobble holds still between ticks instead of drifting every frame.
  float hash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123);
  }

  void main() {
    vArc = aArc;
    vJitter = aJitter;
    vAcross = aSide;

    // Sketchy wobble: nudge this segment's endpoints a little,
    // re-rolled every boil tick, so the stroke visibly resettles
    // instead of smoothly sliding around.
    float seed = aJitter + uBoilTime;
    vec3 wobble = vec3(
      hash(vec2(seed, 1.0)) - 0.5,
      hash(vec2(seed, 2.0)) - 0.5,
      hash(vec2(seed, 3.0)) - 0.5
    ) * uThickness * 1.5;

    vec3 start = aStart + wobble;
    vec3 end = aEnd + wobble;

    vec4 clipStart = projectionMatrix * modelViewMatrix * vec4(start, 1.0);
    vec4 clipEnd = projectionMatrix * modelViewMatrix * vec4(end, 1.0);

    vec2 screenStart = clipStart.xy / clipStart.w * uResolution;
    vec2 screenEnd = clipEnd.xy / clipEnd.w * uResolution;

    vec2 dir = normalize(screenEnd - screenStart);
    vec2 normal = vec2(-dir.y, dir.x);

    // position.z carries which endpoint this vertex belongs to
    // (0 = start, 1 = end) — packed in on the CPU side.
    vec2 basePoint = mix(screenStart, screenEnd, position.z);
    vec4 baseClip = mix(clipStart, clipEnd, position.z);

    vec2 screenPos = basePoint + normal * aSide * uThickness;

    vec4 clip = baseClip;
    clip.xy = screenPos / uResolution * clip.w;

    gl_Position = clip;
  }
`;

const fragmentShader = /* glsl */ `
  uniform vec3 uColor;
  uniform float uGapFrequency; // how many lifts per unit of arc length
  uniform float uGapWidth;     // how much of each cycle is a gap
  uniform float uBoilTime;

  varying float vArc;
  varying float vJitter;
  varying float vAcross;

  float hash(float n) {
    return fract(sin(n) * 43758.5453123);
  }

  void main() {
    // Rounded caps: fade out near the edges of the stroke's width.
    float edgeFade = 1.0 - smoothstep(0.7, 1.0, abs(vAcross));

    // Lifts: walk along the stroke's arc length and periodically stop
    // inking. Re-rolled on every boil tick so gaps resettle rather
    // than sliding smoothly along the line.
    float cycle = fract(vArc * uGapFrequency + hash(vJitter + uBoilTime) * 10.0);
    float lifted = step(cycle, uGapWidth);

    if (lifted > 0.5 || edgeFade < 0.05) discard;

    gl_FragColor = vec4(uColor, edgeFade);
  }
`;

export function createLineArtMaterial({
  color = new THREE.Color("#111111"),
  thickness = 1.2,
  gapFrequency = 0.35,
  gapWidth = 0.18,
  depthTest = true,
} = {}) {
  return new THREE.ShaderMaterial({
    uniforms: {
      uColor: { value: color },
      uThickness: { value: thickness },
      uResolution: { value: new THREE.Vector2(1, 1) },
      uBoilTime: { value: 0 },
      uGapFrequency: { value: gapFrequency },
      uGapWidth: { value: gapWidth },
    },
    vertexShader,
    fragmentShader,
    transparent: true,
    depthWrite: false,
    depthTest,
    side: THREE.DoubleSide,
  });
}

// ── Edge adjacency, built once per geometry ───────────────────────

function buildEdgeAdjacency(geometry) {
  const pos = geometry.attributes.position;
  const index = geometry.index
    ? geometry.index.array
    : Uint32Array.from({ length: pos.count }, (_, i) => i);

  const edgeMap = new Map(); // "a_b" (a < b) -> { a, b, faces: [faceIndex, ...] }
  const faceNormals = [];

  const vA = new THREE.Vector3();
  const vB = new THREE.Vector3();
  const vC = new THREE.Vector3();
  const edgeAB = new THREE.Vector3();
  const edgeAC = new THREE.Vector3();
  const normal = new THREE.Vector3();

  for (let i = 0; i < index.length; i += 3) {
    const ia = index[i];
    const ib = index[i + 1];
    const ic = index[i + 2];

    vA.fromBufferAttribute(pos, ia);
    vB.fromBufferAttribute(pos, ib);
    vC.fromBufferAttribute(pos, ic);

    edgeAB.subVectors(vB, vA);
    edgeAC.subVectors(vC, vA);
    normal.crossVectors(edgeAB, edgeAC).normalize();

    const faceIndex = faceNormals.length;
    faceNormals.push(normal.clone());

    const faceEdges = [
      [ia, ib],
      [ib, ic],
      [ic, ia],
    ];

    faceEdges.forEach(([a, b]) => {
      const key = a < b ? `${a}_${b}` : `${b}_${a}`;
      let edge = edgeMap.get(key);
      if (!edge) {
        edge = { a, b, faces: [] };
        edgeMap.set(key, edge);
      }
      edge.faces.push(faceIndex);
    });
  }

  return { edges: [...edgeMap.values()], faceNormals, positionAttr: pos };
}

// ── Chaining active edges into strokes, tracking arc length ──────

function chainEdgesIntoStrokes(activeEdges) {
  const byVertex = new Map(); // vertex index -> edges touching it

  activeEdges.forEach((edge) => {
    [edge.a, edge.b].forEach((v) => {
      if (!byVertex.has(v)) byVertex.set(v, []);
      byVertex.get(v).push(edge);
    });
  });

  const visited = new Set();
  const strokes = [];

  const extend = (chain, fromVertex, atEnd) => {
    let current = fromVertex;
    // Walk through degree-2 vertices for as long as there's exactly
    // one unvisited edge to continue onto. Branch points and dead
    // ends stop the walk — each becomes the start of its own stroke.
    // eslint-disable-next-line no-constant-condition
    while (true) {
      const candidates = (byVertex.get(current) || []).filter(
        (e) => !visited.has(e),
      );
      if (candidates.length !== 1) break;
      const next = candidates[0];
      visited.add(next);
      if (atEnd) chain.push(next);
      else chain.unshift(next);
      current = next.a === current ? next.b : next.a;
    }
  };

  activeEdges.forEach((startEdge) => {
    if (visited.has(startEdge)) return;

    const chain = [startEdge];
    visited.add(startEdge);

    extend(chain, startEdge.b, true);
    extend(chain, startEdge.a, false);

    strokes.push(chain);
  });

  return strokes;
}

// ── The effect itself ─────────────────────────────────────────────

export class ObjectSpaceLineArt {
  constructor(mesh, options = {}) {
    this.sourceMesh = mesh;
    this.boilRate = options.boilRate ?? 6; // recomputes per second
    this._boilTick = -1;

    const { edges, faceNormals, positionAttr } = buildEdgeAdjacency(
      mesh.geometry,
    );
    this.edges = edges;
    this.faceNormals = faceNormals;
    this.positionAttr = positionAttr;

    this.material = createLineArtMaterial(options);
    this.geometry = new THREE.BufferGeometry();
    this.object = new THREE.Mesh(this.geometry, this.material);
    this.object.frustumCulled = false;

    this._inverseMatrix = new THREE.Matrix4();
    this._localCamPos = new THREE.Vector3();
    this._vA = new THREE.Vector3();
    this._vB = new THREE.Vector3();
    this._toCam = new THREE.Vector3();
  }

  setResolution(width, height) {
    this.material.uniforms.uResolution.value.set(width, height);
  }

  // Call every frame. Internally this only recomputes the silhouette
  // a few times a second (the "boil") and holds still in between.
  update(camera, elapsedTime) {
    const tick = Math.floor(elapsedTime * this.boilRate);
    this.material.uniforms.uBoilTime.value = tick;

    if (tick === this._boilTick) return;
    this._boilTick = tick;

    this._rebuild(camera);
  }

  _rebuild(camera) {
    this.sourceMesh.updateWorldMatrix(true, false);
    this._inverseMatrix.copy(this.sourceMesh.matrixWorld).invert();
    this._localCamPos.copy(camera.position).applyMatrix4(this._inverseMatrix);

    const active = [];

    this.edges.forEach((edge) => {
      if (edge.faces.length === 1) {
        active.push(edge); // open/boundary edge — always a contour
        return;
      }

      const [fA, fB] = edge.faces;
      const normalA = this.faceNormals[fA];
      const normalB = this.faceNormals[fB];

      this._vA.fromBufferAttribute(this.positionAttr, edge.a);
      this._toCam.subVectors(this._localCamPos, this._vA);

      const facingA = normalA.dot(this._toCam) > 0;
      const facingB = normalB.dot(this._toCam) > 0;

      if (facingA !== facingB) active.push(edge);
    });

    const strokes = chainEdgesIntoStrokes(active);
    this._buildGeometryFromStrokes(strokes);
  }

  _buildGeometryFromStrokes(strokes) {
    const positions = [];
    const starts = [];
    const ends = [];
    const sides = [];
    const arcs = [];
    const jitters = [];
    const indices = [];

    let vertexCount = 0;

    strokes.forEach((chain, strokeIndex) => {
      let arcLength = 0;
      const jitterSeed = strokeIndex * 17.0;

      chain.forEach((edge) => {
        this._vA.fromBufferAttribute(this.positionAttr, edge.a);
        this._vB.fromBufferAttribute(this.positionAttr, edge.b);

        const segLength = this._vA.distanceTo(this._vB);
        const arcStart = arcLength;
        arcLength += segLength;

        // Each segment becomes a quad: 4 vertices, 2 triangles.
        // [side, whichEnd] — whichEnd (0/1) is packed into
        // position.z and read by the vertex shader.
        const quad = [
          [-1, 0],
          [1, 0],
          [-1, 1],
          [1, 1],
        ];

        quad.forEach(([side, whichEnd]) => {
          positions.push(0, 0, whichEnd);
          starts.push(this._vA.x, this._vA.y, this._vA.z);
          ends.push(this._vB.x, this._vB.y, this._vB.z);
          sides.push(side);
          arcs.push(whichEnd === 0 ? arcStart : arcStart + segLength);
          jitters.push(jitterSeed);
        });

        const base = vertexCount;
        indices.push(base, base + 1, base + 2, base + 1, base + 3, base + 2);
        vertexCount += 4;
      });
    });

    this.geometry.dispose();
    this.geometry = new THREE.BufferGeometry();
    this.geometry.setAttribute(
      "position",
      new THREE.Float32BufferAttribute(positions, 3),
    );
    this.geometry.setAttribute(
      "aStart",
      new THREE.Float32BufferAttribute(starts, 3),
    );
    this.geometry.setAttribute(
      "aEnd",
      new THREE.Float32BufferAttribute(ends, 3),
    );
    this.geometry.setAttribute(
      "aSide",
      new THREE.Float32BufferAttribute(sides, 1),
    );
    this.geometry.setAttribute("aArc", new THREE.Float32BufferAttribute(arcs, 1));
    this.geometry.setAttribute(
      "aJitter",
      new THREE.Float32BufferAttribute(jitters, 1),
    );
    this.geometry.setIndex(indices);

    this.object.geometry = this.geometry;
  }

  dispose() {
    this.geometry.dispose();
    this.material.dispose();
  }
}
